Open index.html for the self-contained before/after gallery and report. Fictional fixtures only. No application, credentials, account data or unrelated private review notes are packaged.
